exports.components = {
    "component---src-pages-index-jsx": () =>
        import ("./../../../src/pages/index.jsx" /* webpackChunkName: "component---src-pages-index-jsx" */ )
}