import React from 'react';
import { Provider } from './src/components/schedule-context';
export default ({ element }) => {
  return <Provider>{element}</Provider>;
};
